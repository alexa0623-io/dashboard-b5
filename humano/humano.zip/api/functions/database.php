<?php
ORM::configure('mysql:host=localhost;dbname=aisi_humano');
ORM::configure('username', 'root');
ORM::configure('password', 'root');
ORM::configure('logging', true);
ORM::configure('return_result_sets', true);

// ORM::configure('mysql:host=localhost;dbname=aisi_humano');
// ORM::configure('username', 'root');
// ORM::configure('password', '');
// ORM::configure('logging', true);
// ORM::configure('return_result_sets', true);